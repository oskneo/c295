
int proc2(int m, int n) {
    int res;
    res = m*n - 12;
    return res;
}
